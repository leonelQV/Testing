public class Sumar{
    public static void main(String[] args) {
        if(args.length==2){
            double nro1=Double.parseDouble(args[0]);
            double nro2=Double.parseDouble(args[1]);
            System.out.println(nro1+nro2);
        }else{
            System.out.println("Se esperan dos números como parámetros de entrada.");
        }
    }
}