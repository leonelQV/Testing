package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CalculadoraApplicationTest {
    @Test
	void pruebaSumarEnteros1(){
		assertEquals(4, Calculadora.sumar(2, 2));
	}
	@Test
	void pruebaSumarEnteros2(){
		assertEquals(35, Calculadora.sumar(20, 15));
	}
	@Test
	void pruebaSumarElementoNeutro1(){
		assertEquals(20, Calculadora.sumar(20, 0));
	}
	@Test
	void pruebaSumarElementoNeutro2(){
		assertEquals(20, Calculadora.sumar(20, -0));
	}
	@Test
	void pruebaSumarElementoNeutro3(){
		assertEquals(0, Calculadora.sumar(0, 0));
	}
	@Test
	void pruebaSumarElementoNeutro4(){
		assertEquals(10, Calculadora.sumar(0, 10));
	}
	@Test
	void pruebaSumarElementosNegativos1(){
		assertEquals(0, Calculadora.sumar(-10, 10));
	}
	@Test
	void pruebaSumarElementosNegativos2(){
		assertEquals(-6, Calculadora.sumar(-10, 4));
	}
	@Test
	void pruebaSumarElementosNegativos3(){
		assertEquals(-2, Calculadora.sumar(10, -12));
	}
	@Test
	void pruebaSumarElementosNegativos4(){
		assertEquals(-20, Calculadora.sumar(-10, -10));
	}

    //Resta 

    @Test
	void pruebaSumarEnteros5(){
		assertEquals(0, Calculadora.restar(2, 2));
	}
	@Test
	void pruebaSumarEnteros6(){
		assertEquals(5, Calculadora.restar(20, 15));
	}
	@Test
	void pruebaSumarElementoNeutro7(){
		assertEquals(20, Calculadora.restar(20, 0));
	}
	@Test
	void pruebaSumarElementoNeutro8(){
		assertEquals(10, Calculadora.restar(20, 10));
	}
	@Test
	void pruebaSumarElementoNeutro9(){
		assertEquals(0, Calculadora.restar(0, 0));
	}
	@Test
	void pruebaSumarElementoNeutro10(){
		assertEquals(-10, Calculadora.restar(0, 10));
	}
	@Test
	void pruebaSumarElementosNegativos11(){
		assertEquals(-20, Calculadora.sumar(-10, 10));
	}
	@Test
	void pruebaSumarElementosNegativos12(){
		assertEquals(-14, Calculadora.restar(-10, 4));
	}
	@Test
	void pruebaSumarElementosNegativos13(){
		assertEquals(24, Calculadora.restar(10, -12));
	}
	@Test
	void pruebaSumarElementosNegativos14(){
		assertEquals(-10, Calculadora.restar(-10, -10));
	}

    //MULTIPLICACION

    @Test
	void pruebaSumarEnteros15(){
		assertEquals(4, Calculadora.multiplicar(2, 2));
	}
	@Test
	void pruebaSumarEnteros16(){
		assertEquals(300, Calculadora.multiplicar(20, 15));
	}
	@Test
	void pruebaSumarElementoNeutro17(){
		assertEquals(0, Calculadora.multiplicar(20, 0));
	}
	@Test
	void pruebaSumarElementoNeutro18(){
		assertEquals(0, Calculadora.multiplicar(20, -0));
	}
	@Test
	void pruebaSumarElementoNeutro19(){
		assertEquals(0, Calculadora.multiplicar(0, 0));
	}
	@Test
	void pruebaSumarElementoNeutro20(){
		assertEquals(0, Calculadora.multiplicar(0, 10));
	}
	@Test
	void pruebaSumarElementosNegativos21(){
		assertEquals(-100, Calculadora.multiplicar(-10, 10));
	}
	@Test
	void pruebaSumarElementosNegativos22(){
		assertEquals(-40, Calculadora.multiplicar(-10, 4));
	}
	@Test
	void pruebaSumarElementosNegativos23(){
		assertEquals(-120, Calculadora.multiplicar(10, -12));
	}
	@Test
	void pruebaSumarElementosNegativos24(){
		assertEquals(100, Calculadora.multiplicar(-10, -10));
	}

    //DIVISION

    @Test
	void pruebaSumarEnteros25(){
		assertEquals(1, Calculadora.dividir(2, 2));
	}
	@Test
	void pruebaSumarEnteros26(){
		assertEquals(10, Calculadora.dividir(20, 2));
	}
	@Test
	void pruebaSumarElementoNeutro27(){
		assertEquals(2, Calculadora.dividir(20, 10));
	}
	@Test
	void pruebaSumarElementoNeutro28(){
		assertEquals(4, Calculadora.dividir(40, 10));
	}
	@Test
	void pruebaSumarElementoNeutro29(){
		assertEquals(36, Calculadora.dividir(144, 4));
	}
	@Test
	void pruebaSumarElementoNeutro30(){
		assertEquals(0, Calculadora.dividir(0, 10));
	}
	@Test
	void pruebaSumarElementosNegativos31(){
		assertEquals(-1, Calculadora.dividir(-10, 10));
	}
	@Test
	void pruebaSumarElementosNegativos32(){
		assertEquals(-5, Calculadora.dividir(-10, 2));
	}
	@Test
	void pruebaSumarElementosNegativos33(){
		assertEquals(-12, Calculadora.dividir(120, -10));
	}
	@Test
	void pruebaSumarElementosNegativos34(){
		assertEquals(-20, Calculadora.dividir(200, -10));
	}
}
