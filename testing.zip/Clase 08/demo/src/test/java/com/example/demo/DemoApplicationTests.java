package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {
	@Test
	void pruebaEjemplo1(){
		assertEquals(true, true);	//verde
	}
	@Test
	void pruebaEjemplo2(){
		//assertEquals(false, true);	//rojo
	}
	@Test
	void pruebaEjemplo3(){
		assertEquals(4, 2+2);				//verde
	}
	@Test
	void pruebaSumarEnteros1(){
		assertEquals(4, Sumar.sumar(2, 2));
	}
	@Test
	void pruebaSumarEnteros2(){
		assertEquals(35, Sumar.sumar(20, 15));
	}
	@Test
	void pruebaSumarElementoNeutro1(){
		assertEquals(20, Sumar.sumar(20, 0));
	}
	@Test
	void pruebaSumarElementoNeutro2(){
		assertEquals(20, Sumar.sumar(20, -0));
	}
	@Test
	void pruebaSumarElementoNeutro3(){
		assertEquals(0, Sumar.sumar(0, 0));
	}
	@Test
	void pruebaSumarElementoNeutro4(){
		assertEquals(10, Sumar.sumar(0, 10));
	}
	@Test
	void pruebaSumarElementosNegativos1(){
		assertEquals(0, Sumar.sumar(-10, 10));
	}
	@Test
	void pruebaSumarElementosNegativos2(){
		assertEquals(-6, Sumar.sumar(-10, 4));
	}
	@Test
	void pruebaSumarElementosNegativos3(){
		assertEquals(-2, Sumar.sumar(10, -12));
	}
	@Test
	void pruebaSumarElementosNegativos4(){
		assertEquals(-20, Sumar.sumar(-10, -10));
	}
}
