package com.example.demo;

public class Calculadora {

    /*
     * Este metodo retorna la suma de los dos parametros de entrada 
     * @param nro1 parametro a operar
     * @param nro2 parametro a operar
     * @return resultado de la operacion 
     */
     
    public static int sumar(int nro1, int nro2){
        //TODO retornar la suma de los dos numeros que ingresan como parametrs 
        return 0;
    }

    /*
     * Este metodo retorna la resta de los dos parametros de entrada 
     * @param nro1 parametro a operar
     * @param nro2 parametro a operar
     * @return resultado de la operacion 
     */

    public static int restar(int nro1, int nro2){
        //TODO retornar la resta de los dos numeros que ingresan como parametrs
        return 0;
    }

    /*
     * Este metodo retorna la multiplicacion de los dos parametros de entrada 
     * @param nro1 parametro a operar
     * @param nro2 parametro a operar
     * @return resultado de la operacion 
     */

    public static int multiplicar(int nro1, int nro2){
        //TODO retornar la multiplicacion de los dos numeros que ingresan como parametrs
        return 0;
    }

    /*
     * Este metodo retorna la division de los dos parametros de entrada 
     * @param nro1 parametro a operar
     * @param nro2 parametro a operar
     * @return resultado de la operacion 
     */

    public static int dividir(int nro1, int nro2){
        //TODO retornar la division de los dos numeros que ingresan como parametrs
        return 0;
    }
}
